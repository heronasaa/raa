1. Go to System environment variables
2. Create TOKEN 
3. Enter your token 
4. Go to index.js and search channel_id
5. Enter your channel_id
6. Run